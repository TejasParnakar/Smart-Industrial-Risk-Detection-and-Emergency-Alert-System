uart0_intr.o: drivers\uart0_intr.c
uart0_intr.o: C:\Keil4\ARM\INC\Philips\lpc21xx.h
uart0_intr.o: drivers\header.h
uart0_intr.o: C:\Keil4\ARM\RV31\INC\stdio.h
