timer0_intr.o: drivers\timer0_intr.c
timer0_intr.o: C:\Keil4\ARM\INC\Philips\lpc21xx.h
