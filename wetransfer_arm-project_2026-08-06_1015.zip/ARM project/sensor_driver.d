.\sensor_driver.o: drivers\sensor_driver.c
.\sensor_driver.o: drivers\header.h
.\sensor_driver.o: C:\Keil_v5\ARM\INC\Philips\lpc21xx.h
.\sensor_driver.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
