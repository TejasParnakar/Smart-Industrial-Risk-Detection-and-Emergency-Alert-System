spi0_driver.o: drivers\spi0_driver.c
spi0_driver.o: C:\Keil4\ARM\INC\Philips\LPC21xx.H
spi0_driver.o: drivers\header.h
spi0_driver.o: C:\Keil4\ARM\RV31\INC\stdio.h
