.\eint_intrs.o: drivers\eint_intrs.c
.\eint_intrs.o: C:\Keil_v5\ARM\INC\Philips\LPC21xx.H
.\eint_intrs.o: drivers\header.h
.\eint_intrs.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
