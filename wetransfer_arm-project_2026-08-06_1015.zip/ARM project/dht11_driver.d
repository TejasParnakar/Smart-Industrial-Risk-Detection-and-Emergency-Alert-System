.\dht11_driver.o: dht11_driver.c
.\dht11_driver.o: header.h
.\dht11_driver.o: C:\Keil_v5\ARM\INC\Philips\lpc21xx.h
.\dht11_driver.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
