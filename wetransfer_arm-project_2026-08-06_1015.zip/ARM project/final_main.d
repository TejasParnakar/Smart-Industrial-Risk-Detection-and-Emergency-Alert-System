.\final_main.o: drivers\final_main.c
.\final_main.o: drivers\header.h
.\final_main.o: C:\Keil_v5\ARM\INC\Philips\lpc21xx.h
.\final_main.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
