.\adc_driver.o: drivers\adc_driver.c
.\adc_driver.o: C:\Keil_v5\ARM\INC\Philips\LPC21xx.H
.\adc_driver.o: drivers\header.h
.\adc_driver.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
