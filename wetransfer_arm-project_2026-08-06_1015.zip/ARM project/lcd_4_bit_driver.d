.\lcd_4_bit_driver.o: drivers\lcd_4_bit_driver.c
.\lcd_4_bit_driver.o: C:\Keil_v5\ARM\INC\Philips\LPC21xx.H
.\lcd_4_bit_driver.o: drivers\header.h
.\lcd_4_bit_driver.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
