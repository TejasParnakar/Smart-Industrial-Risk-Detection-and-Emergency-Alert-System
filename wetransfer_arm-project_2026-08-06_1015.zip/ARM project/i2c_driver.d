.\i2c_driver.o: drivers\i2c_driver.c
.\i2c_driver.o: C:\Keil_v5\ARM\INC\Philips\LPC21xx.H
.\i2c_driver.o: drivers\header.h
.\i2c_driver.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
