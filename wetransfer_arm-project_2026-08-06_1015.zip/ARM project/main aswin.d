.\main aswin.o: MAIN ASWIN.c
.\main aswin.o: header.h
.\main aswin.o: C:\Keil_v5\ARM\INC\Philips\lpc21xx.h
.\main aswin.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
