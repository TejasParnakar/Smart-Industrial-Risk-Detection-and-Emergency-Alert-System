.\uart0_driver.o: drivers\uart0_driver.c
.\uart0_driver.o: C:\Keil_v5\ARM\INC\Philips\LPC21xx.H
.\uart0_driver.o: drivers\header.h
.\uart0_driver.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdio.h
