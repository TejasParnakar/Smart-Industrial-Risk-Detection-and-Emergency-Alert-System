.\delay.o: drivers\delay.c
.\delay.o: C:\Keil_v5\ARM\INC\Philips\LPC21xx.H
