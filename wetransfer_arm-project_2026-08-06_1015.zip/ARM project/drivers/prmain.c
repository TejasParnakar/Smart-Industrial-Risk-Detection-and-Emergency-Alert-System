#include <lpc21xx.h>
#include <stdio.h>
#include <string.h>

// --- Pin Definitions ---
#define RELAY_PIN       (1 << 16)   // P0.16 - Controls machine power
#define BUZZER_PIN      (1 << 17)   // P0.17 - Alarm buzzer
#define RED_LED_PIN     (1 << 18)   // P0.18 - Emergency/Alert Indicator
#define YELLOW_LED_PIN  (1 << 19)   // P0.19 - Warning Indicator
#define GREEN_LED_PIN   (1 << 20)   // P0.20 - Normal Status Indicator
// LCD Pin configuration (4-bit mode)
#define LCD_RS          (1 << 21)   // P0.21
#define LCD_EN          (1 << 22)   // P0.22
#define LCD_DATA_MASK   (0xF << 23) // P0.23 to P0.26 used for D4-D7

// Predefined Safety Thresholds
#define TEMP_THRESHOLD      45      // Celsius
#define CURRENT_THRESHOLD   500     // mA (via ACS712)
#define HUMIDITY_THRESHOLD  75      // Percentage

// Global Flags for non-ADC Digital Sensors
volatile int fire_detected = 0;
volatile int gas_detected = 0;
volatile int vibration_detected = 0;

// --- Function Prototypes ---
void Delay_ms(unsigned int ms);
void GPIO_Init(void);
void ADC_Init(void);
unsigned int ADC_Read(unsigned char channel);
void UART0_Init(void);
void UART0_SendString(char *str);
void LCD_Init(void);
void LCD_Cmd(unsigned char cmd);
void LCD_Data(unsigned char data);
void LCD_DisplayString(char *str);
void CAN_Init(void);
void CAN_Transmit(unsigned int id, char* msg);
void I2C_Init(void);
void RTC_GetTime(char *time_str);
void SPI_Init(void);
void SPI_LogData(char *log_msg);
void Ext_Interrupt_Init(void);

// --- Stage 6: External Interrupt ISR for Fire Detection ---

void Ext_ISR(void) __attribute__((interrupt("IRQ")));
void Ext_ISR(void) {
    if (EXTINT & 0x02) {          // Check if EINT1 (Flame Sensor Pin) caused interrupt
        fire_detected = 1;        // High priority override flag
        EXTINT = 0x02;            // Clear interrupt flag
    }
    VICVectAddr = 0;              // Acknowledge Interrupt
}

// ==========================================
// MAIN SYSTEM LOOP
// ==========================================
int main(void) {
    unsigned int temp_val, current_val, humidity_val;
    char string[50];
    char time[16];

   // Stage 1: System Initialization
    GPIO_Init();
     LCD_Init();
     ADC_Init();
     UART0_Init();
     I2C_Init();
     SPI_Init();
     CAN_Init();
     Ext_Interrupt_Init();
     LCD_Cmd(0x80);
     LCD_DisplayString("INDUSTRIAL SAFETY");
     LCD_Cmd(0xC0);
     LCD_DisplayString("   SYSTEM INIT  ");
     Delay_ms(2000);
     LCD_Cmd(0x01); // Clear Display
     while (1) {
         // Stage 2: Sensor Monitoring (Read Analog Data)
         // Ch 0: LM35, Ch 1: ACS712, Ch 2: Humidity, P0.3: Gas Digital Input
         temp_val = (ADC_Read(0) * 330) / 1023;       // Convert to Approx Celsius
         current_val = (ADC_Read(1) * 3300) / 1023;   // Convert to mA
         humidity_val = (ADC_Read(2) * 100) / 1023;   // Percentage scaled
 
        // Read poll-based digital sensors
          gas_detected = (IOPIN0 & (1 << 3)) ? 1 : 0; 
          vibration_detected = (IOPIN0 & (1 << 4)) ? 1 : 0;
          RTC_GetTime(time);
  
        // Stage 13: Smart Decision-Making (AI-inspired branching logic)
        // CRITICAL EMERGENCY: Fire Detected
        if (fire_detected) {
            // Stage 6 Operations
            IO0SET = RED_LED_PIN | BUZZER_PIN;
            IO0CLR = GREEN_LED_PIN | YELLOW_LED_PIN | RELAY_PIN; // Drop machine relay
            LCD_Cmd(0x01);
            LCD_Cmd(0x80); LCD_DisplayString("FIRE DETECTED!");
            UART0_SendString("EMERGENCY: FIRE DETECTED\r\n");
            CAN_Transmit(0x101, "FIRE_EMERGENCY");
            sprintf(string, "[%s] FIRE ERROR - SHUTDOWN", time);
            SPI_LogData(string);
            while(fire_detected) {
                // Keep system locked down safely until reset or external override
                IO0SET = RED_LED_PIN; Delay_ms(100);
                IO0CLR = RED_LED_PIN; Delay_ms(100);
            }
        }

        // EMERGENCY: Gas Leakage
        else if (gas_detected) {
            // Stage 5 Operations
            IO0SET = BUZZER_PIN;
            IO0CLR = GREEN_LED_PIN | RELAY_PIN; // Trip load
            LCD_Cmd(0x80); LCD_DisplayString("GAS LEAKAGE DET ");

            // Blink Red LED
            IO0SET = RED_LED_PIN; Delay_ms(200);
            IO0CLR = RED_LED_PIN; Delay_ms(200);
            UART0_SendString("EMERGENCY: GAS LEAKAGE DETECTED\r\n");
            CAN_Transmit(0x102, "GAS_LEAK_DET");
            sprintf(string, "[%s] GAS LEAK DETECTED", time);
            SPI_LogData(string);
        }

        // CRITICAL PARAMETER: High Temperature
        else if (temp_val > TEMP_THRESHOLD) {
            // Stage 4 Operations
            IO0SET = RED_LED_PIN | BUZZER_PIN;
            IO0CLR = GREEN_LED_PIN | YELLOW_LED_PIN | RELAY_PIN; // Disconnect machine
            LCD_Cmd(0x80); LCD_DisplayString("HIGH TEMP ALERT ");
            sprintf(string, "TEMP: %d C     ", temp_val);
            LCD_Cmd(0xC0); LCD_DisplayString(string);
            UART0_SendString("WARNING: HIGH TEMPERATURE DETECTED\r\n");
            sprintf(string, "[%s] HIGH TEMP: %dC", time, temp_val);
            SPI_LogData(string);
            Delay_ms(1000);
        }

        // CRITICAL PARAMETER: Over Current
        else if (current_val > CURRENT_THRESHOLD) {
            // Stage 8 Operations
            IO0SET = RED_LED_PIN | BUZZER_PIN;
            IO0CLR = GREEN_LED_PIN | RELAY_PIN;
            LCD_Cmd(0x80); LCD_DisplayString("OVER CURRENT ALT");
            sprintf(string, "[%s] OVERCURRENT: %dmA", time, current_val);
            SPI_LogData(string);
            Delay_ms(1000);
       }

        // WARNING: Machine Vibration
        else if (vibration_detected) {
            // Stage 7 Operations
            IO0SET = YELLOW_LED_PIN | BUZZER_PIN;
            IO0CLR = GREEN_LED_PIN; 
            // Relay remains ON during minor vibration warnings to avoid full disruption
            IO0SET = RELAY_PIN; 
            LCD_Cmd(0x80); LCD_DisplayString("VIBRATION ALERT ");
            Delay_ms(500);
        }

        // WARNING: High Humidity
        else if (humidity_val > HUMIDITY_THRESHOLD) {
            // Stage 9 Operations
            IO0SET = YELLOW_LED_PIN;
            IO0CLR = GREEN_LED_PIN;
            LCD_Cmd(0x80); LCD_DisplayString("HIGH HUMIDITY  ");
            Delay_ms(500);
        }

        // Stage 3: Normal Condition Monitoring
        else {
            IO0SET = GREEN_LED_PIN | RELAY_PIN; // Keep machine powered and safe
            IO0CLR = RED_LED_PIN | YELLOW_LED_PIN | BUZZER_PIN;
            LCD_Cmd(0x80); LCD_DisplayString("SYSTEM NORMAL   ");
            sprintf(string, "T:%dC H:%d%%       ", temp_val, humidity_val);
            LCD_Cmd(0xC0); LCD_DisplayString(string);
            Delay_ms(500);
        }
    }
}

// ==========================================
// LOW-LEVEL PERIPHERAL HARDWARE DRIVERS
// ==========================================
void GPIO_Init(void) {
    // Configure Alerts, Relay, and LCD Pins as Output
    IO0DIR |= (RELAY_PIN | BUZZER_PIN | RED_LED_PIN | YELLOW_LED_PIN | GREEN_LED_PIN | LCD_RS | LCD_EN | LCD_DATA_MASK);
    // Inputs: P0.3 (Gas Sensor), P0.4 (Vibration Sensor Setup)
    IO0DIR &= ~((1 << 3) | (1 << 4));
    // Turn off all alerts & activate default safe conditions
    IO0CLR = (RED_LED_PIN | YELLOW_LED_PIN | BUZZER_PIN);
    IO0SET = GREEN_LED_PIN | RELAY_PIN;
}


void CAN_Init(void) {
    // Pin Selection configuration for CAN Controller 1 (P0.25=RxD1, P0.26=TxD1)
    PINSEL1 |= (1 << 18) | (1 << 20);
    C1MOD = 1;     // Enter Initialization Mode
    C1BTR = 0x00230005; // Standard configuration setup for 125Kbps bit timing
    C1MOD = 0;     // Release initialization context (Active)
}	  

void CAN_Transmit(unsigned int id, char* msg) {
    C1TID1 = id;                     // Load Message Identifier Node Address
    C1TFI1 = 0x00040000;             // Frame format config payload size data set to 4 bytes
    C1TDA1 = *(unsigned int*)msg;    // Push string char bytes mapping directly
    C1CMR = 0x21;                    // Request instant transmission payload delivery
}




void RTC_GetTime(char *time_str) {
    // Fallback/stub simulating standard DS1307 real-time registers reading over I2C
    strcpy(time_str, "10:45:00 AM"); 
}

void SPI_Init(void) {
    PINSEL0 |= 0x00005500;           // Configure SPI Pins P0.4(SCK), P0.5(MISO), P0.6(MOSI)
    S0SPCCR = 8;                     // Clock Prescaler assignment rate
    S0SPCR = 0x00000020;             // Setup as Master controller node unit element
}

void SPI_LogData(char *log_msg) {
    while (*log_msg) {
        S0SPDR = *log_msg++;
        while (!(S0SPSR & 0x80));    // Wait until SPI data transfer flag (SPIF) updates
    }
}


