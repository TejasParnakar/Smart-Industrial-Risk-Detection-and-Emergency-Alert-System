#include<lpc21xx.h>
#include "header.h"
extern u8 f,buf;
void uart0_handler(void)__irq
{
s8 v= U0IIR;
v&=0x0E;
if(v==4)
{
buf = U0RBR;
f=1;
}
VICVectAddr=0;
}
void config_uart0_intr(void)
{
VICIntSelect=0;
VICVectCntl0=6|(1<<5);
VICVectAddr0=(u32)uart0_handler;
VICIntEnable=(1<<6);
U0IER=3;
}
