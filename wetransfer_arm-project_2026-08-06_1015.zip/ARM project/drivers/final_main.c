//final_main.c
#include "header.h"

 int fire_detected=0;


//void rtc_time(char *time)
//{
//		unsigned char h,m,s;
//		h=i2c_read(0xD1,0x2);
//		m=i2c_read(0xD1,0x1);
//		s=i2c_read(0xD1,0x0);
//		if(h>>6&1)
//		{
//				if(h>>5&1)
//					sprintf(time,"%x:%x:%x %s",h,m,s,"PM");
//				else
//					sprintf(time,"%x:%x:%x %s",h,m,s,"AM");
//		}
//		else
//		sprintf(time,"%x:%x:%x",h,m,s);
//}



int main ()
{
u8 humidity=0;
u8 temperature=0;
u32 gas_value = 0;
volatile int d;
int adc;
float voltage;
int current;
char time[15];
config_eint0();
adc_init();
uart0_init(9600);
//i2c_init();

uart0_tx_string("\r\n PROJECT DONE BY: ");
uart0_tx_string("\r\n Aarthi ->  v25be7a6.");
uart0_tx_string("\r\n Gauri  ->  v25be7g1.");
uart0_tx_string("\r\n Laxman ->  v25be7l1.");
uart0_tx_string("\r\n Rushil ->  v25be7r1.\r\n");


uart0_tx_string("DHT Sensor initialized......\r\n");
//temp & humid....
if(Read_DHT11(&humidity,&temperature)){
uart0_tx_string("Humidity:");
uart0_tx_integer(humidity);
uart0_tx_string("%\r\nTemperature:");
uart0_tx_integer(temperature);
uart0_tx_string(".C\r\n");
}
else
uart0_tx_string("DHT11 Sensor communication error!!!\r\n");

delay_ms(2000);

//.................................

// GAS sensor...............

uart0_tx_string("Gas Sensor (ADC CH0) Test Initialized...\r\n");
gas_value = adc_read(0); // Read analog values from Channel 0

uart0_tx_string("Gas Raw ADC Value: ");
uart0_tx_integer(gas_value);
uart0_tx_string("\r\n");
delay_ms(2000);

//..................................

//vibration sensor..............

// Set up P0.17 as normal GPIO Input
PINSEL0 &= ~(3 << 2); // Set P0.17 bits to 00 (GPIO)
IODIR0 &= ~(1 << 17); // Direction: Input

uart0_tx_string("Vibration Sensor Test Initialized...\r\n");
if (IOPIN0 & (1 << 17)) {
uart0_tx_string("Vibration Status: SHAKING / WARN\r\n");
} 
else {
uart0_tx_string("Vibration Status: STILL / OK\r\n");
}
delay_ms(2000);
//.......................................................

//Current sensor

PINSEL1|=1<<22;
adc=adc_read(1);
voltage=adc*3.3/1023;
//uart0_tx_string("\r\nvoltage:");
delay_ms(100);
//uart0_tx_float(voltage);
delay_ms(100);
current=(voltage/200);
uart0_tx_string("\r\ncurrent:");
uart0_tx_float(current);
delay_ms(100);
//.......................................................

//Fire sensor
IODIR0|=1<<16;

while(1){

		  //rtc_time(time);

//Temp & Humidity sensor
	if(Read_DHT11(&humidity,&temperature)){	
			if(temperature>50){
			uart0_tx_string("HIGH TEMPERATURE WARNING!!!!\r\n");
			uart0_tx_string("\r\n");
			uart0_tx_string(time);
			}
			if(humidity>70){
			uart0_tx_string("HIGH HUMIDITY WARNING!!!!\r\n");
			uart0_tx_string("\r\n");
		//	uart0_tx_string(time) ;
			}
		}

//Gas sensor
gas_value = adc_read(0); // Read analog values from Channel 0
if(gas_value>400)
{
		uart0_tx_string("HAZARDOUS GAS WARNING!!!\r\n");
					uart0_tx_string("\r\n");
		//	uart0_tx_string(time);
		//			uart0_tx_string("\r\n");
}

// Vibration sensor
if (IOPIN0 & (1 << 17)) {
uart0_tx_string("Vibration Status: SHAKING / WARN\r\n");
			uart0_tx_string("\r\n");
		//	uart0_tx_string(time);
	  					uart0_tx_string("\r\n");

}

//Current sensor
adc=adc_read(1); // Read analog values from Channel 1
voltage=adc*3.3/1023;
delay_ms(1000);
current=(voltage/200);
if(current>3.5||current<(-10))
{
uart0_tx_string("\r\n Over Current! Alert.");
			uart0_tx_string("\r\n");
		//	uart0_tx_string(time);
		//						uart0_tx_string("\r\n");

}

//Fire Sensor
if(fire_detected)
{
uart0_tx_string("\r\n Fire Alert! Run for safety");
 			uart0_tx_string("\r\n");
	 fire_detected=0;
		//	uart0_tx_string(time);
		//						uart0_tx_string("\r\n");

			}
			


}







}



