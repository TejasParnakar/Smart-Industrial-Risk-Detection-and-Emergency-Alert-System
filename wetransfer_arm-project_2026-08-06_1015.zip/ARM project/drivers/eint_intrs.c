#include <LPC21xx.H>
#include "header.h"
extern int fire_detected;
//extern int gas_detected;
//extern int vibration_detected;

void eint0_handler(void)__irq
{
EXTINT=1;
fire_detected=1;
VICVectAddr=0;
}
void config_eint0(void)
{
PINSEL1 |= 0X1;
EXTMODE=1;
EXTPOLAR=1;
VICIntSelect=0;
VICVectCntl0=14|(1<<5);
VICVectAddr0=(u32)eint0_handler;
VICIntEnable=(1<<14);
}

////EINT1 handler
//void eint1_handler(void)__irq
//{
//EXTINT=2;
//gas_detected=1;
//VICVectAddr=0;
//}
//void config_eint1(void)
//{
//PINSEL0 |= 0X20000000;
//EXTMODE=0;
//EXTPOLAR=0;
//VICIntSelect=0;
//VICVectCntl1=15|(1<<5);
//VICVectAddr1=(u32)eint1_handler;
//VICIntEnable=(1<<15);
//}
//
////EINT2 handler
//void eint2_handler(void)__irq
//{
//EXTINT=4;
//vibration_detected=1;
//VICVectAddr=0;
//}
//void config_eint2(void)
//{
//PINSEL0 |= 0X80000000;
//EXTMODE=0;
//EXTPOLAR=0;
//VICIntSelect=0;
//VICVectCntl3=16|(1<<5);
//VICVectAddr3=(u32)eint2_handler;
//VICIntEnable=(1<<16);
//}
//
////EINT3 handler
//void eint3_handler(void)__irq
//{
//EXTINT=8;
//fire_detected=0;
//gas_detected=0;
//vibration_detected=0;
//VICVectAddr=0;
//}
//void config_eint3(void)
//{
//PINSEL1 |= 0X300;
//EXTMODE=0;
//EXTPOLAR=0;
//VICIntSelect=0;
//VICVectCntl1=17|(1<<5);
//VICVectAddr1=(u32)eint3_handler;
//VICIntEnable=(1<<17);
//}
