#include<LPC21xx.h>
#include"header.h"
int main()
{
int adc;
float voltage;
int current;
PINSEL1|=1<<22;
adc_init();
uart0_init(9600);
 while(1)
{
adc=adc_read(0);
voltage=adc*3.3/1023;
//uart0_tx_string("\r\nvoltage:");
delay_ms(1000);
//uart0_tx_float(voltage);
delay_ms(100);
current=((voltage-2)/0.185);
uart0_tx_string("\r\ncurrent:");
uart0_tx_float(current);
delay_ms(100);
}
}
