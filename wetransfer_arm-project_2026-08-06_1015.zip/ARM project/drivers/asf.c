#include <lpc21xx.h>
//#include <stdio.h>
#define THRESHOLD_TEMP 60 // 60�C
#define THRESHOLD_GAS 500 // ADC value
#define THRESHOLD_VIB 400 // ADC value
// LCD Pins - assuming 4-bit mode on P0.0 to P0.7
#define RS (1<<8)
#define EN (1<<9)
#define LCD_DATA (0xFF<<0)

void delay_ms(unsigned int ms) {
    unsigned int i,j;
    for(i=0;i<ms;i++)
        for(j=0;j<6000;j++);
}

// LCD Functions
void LCD_cmd(unsigned char cmd) {
    IOCLR0 = LCD_DATA | RS;
    IOSET0 = (cmd<<0);
    IOSET0 = EN;
    delay_ms(2);
    IOCLR0 = EN;
    IOCLR0 = LCD_DATA;
    IOSET0 = (cmd<<4);
    IOSET0 = EN;
    delay_ms(2);
    IOCLR0 = EN;
}

void LCD_data(unsigned char data) {
    IOSET0 = RS;
    IOSET0 = (data<<0);
    IOSET0 = EN;
    delay_ms(2);
    IOCLR0 = EN;
    IOCLR0 = LCD_DATA;
    IOSET0 = (data<<4);
    IOSET0 = EN;
    delay_ms(2);
    IOCLR0 = EN;
}

void LCD_init() {
    IODIR0 |= LCD_DATA | RS | EN;
    delay_ms(20);
    LCD_cmd(0x02); // 4-bit
    LCD_cmd(0x28); // 2 line
    LCD_cmd(0x0C); // Display on
    LCD_cmd(0x06); // Entry mode
    LCD_cmd(0x01); // Clear
}

void LCD_string(char *str) {
   while(*str) LCD_data(*str++);
}

// ADC Init for LPC2129 - Channel 0,1,2

void ADC_init() {
   PINSEL1 |= 0x15400000; // P0.28=AD0.1, P0.29=AD0.2, P0.30=AD0.3
    ADCR = 0x00200400; // Select CH1,CH2,CH3, 10-bit, CLKDIV=4
}


// Read ADC channel 0-7

unsigned int ADC_read(int ch) {
    ADCR|=1<<ch;
	ADCR|=1<<24;
	while((ADDR>>31&1)==0);
	ADCR^=1<<24;
	ADCR^=1<<ch;
	return ((ADDR>>6)&0x3ff);

							  
}


// Output Pins

#define RED_LED (1<<10)
#define GREEN_LED (1<<11)
#define BUZZER (1<<12)
#define RELAY (1<<13)

void alert_system(int risk) {
    if(risk) {
        IOSET0 = RED_LED | BUZZER | RELAY; // Alert ON, Machine OFF
        IOCLR0 = GREEN_LED;
        LCD_cmd(0xC0);
        LCD_string("RISK DETECTED!");
    } else {
        IOSET0 = GREEN_LED;
        IOCLR0 = RED_LED | BUZZER | RELAY;
        LCD_cmd(0xC0);
        LCD_string("SYSTEM NORMAL ");
    }
}

int main() {
    unsigned int temp_val, gas_val, vib_val;
    float temperature;
    int risk = 0;
    IODIR0 |= RED_LED | GREEN_LED | BUZZER | RELAY;
    LCD_init();
    ADC_init();
    LCD_cmd(0x80);
    LCD_string("Smart Risk Sys");
    delay_ms(1000);
    while(1) {
        risk = 0;
       // Read Sensors
        temp_val = ADC_read(1); // LM35 on AD0.1
        gas_val = ADC_read(2); // MQ2 on AD0.2
        vib_val = ADC_read(3); // Vibration on AD0.3
        // Convert LM35: 10mV per �C, Vref=3.3V, 10-bit ADC
        temperature = (temp_val * 3.3 * 100) / 1023; 
        // Display on LCD
        LCD_cmd(0x80);
        printf_lcd: // pseudo - you can format and send
        LCD_string("T:"); 
        // Add number printing function here
     // Check thresholds
       if(temperature > THRESHOLD_TEMP || gas_val > THRESHOLD_GAS || vib_val > THRESHOLD_VIB) {
            risk = 1;
        }
       alert_system(risk);
        delay_ms(500);
    }
}
