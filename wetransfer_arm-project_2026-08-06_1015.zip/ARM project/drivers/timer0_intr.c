#include<lpc21xx.h>
#include"header.h"
u32 count2;
void timer1_handler(void)_irq
{
T1IR=1;
count2++;
VICVectAddr=0;
}
void config_timer1_intr(void)
{
T1PC=0;
T1PR=14999;
T1MR0=1;
T1MCR=3;
VICIntSelect=0;
VICVectCntl0=5|(1<<5);
VICVectAddr0=(u32)timer1_Handler;
VICIntEnable=(1<<5);
T1TCR=1;
}

