#include <LPC21xx.H>
#include "header.h"
#define THRE (U0LSR>>5&1)
#define RDR (U0LSR>>0&1)
void uart0_init(unsigned int baud)
{
int pclk,result=0;
if(VPBDIV==0x00)
pclk=15000000;
else if(VPBDIV==0x01)
pclk=60000000;
else if(VPBDIV==0x02)
pclk=30000000;
result=pclk/(16*baud);
PINSEL0 |=0x5;
U0LCR=0x83;
U0DLL=result&0xFF;
U0DLM=result>>8&0xFF;
U0LCR=0x03;
}


void uart0_tx(unsigned char data)
{
U0THR=data;
while(THRE==0);
}


unsigned char uart0_rx()
{
while(RDR==0);
return U0RBR;
}

void uart0_tx_string(char *p)
{
while(*p!=0)
{
uart0_tx(*p);
p++;
}
}
void uart0_rx_string(unsigned char *p,int len)
{
int i;
for(i=0;i<len;i++)
{
p[i]=uart0_rx();
if(p[i]=='\r') 
break; 
}
p[i]='\0';
}

void uart0_tx_integer(int n)
{
	char a[10];
	int i;
	if(n<0)
	{
		uart0_tx('-');
		n=-n;
	}
	if(n==0)
	{
		uart0_tx('0');
		return;
	}
	for(i=0;n;n/=10,i++)
		a[i]=n%10+48;
	for(i-=1;i>=0;i--)
		uart0_tx(a[i]);
}

void uart0_tx_float(float f)
{
	int n;
	if(f<0)
	{
		uart0_tx('-');
		f=-f;
	}
	if(f==0)
	{
		uart0_tx_string("0.0");
		return;
	}
	n=f;
	uart0_tx_integer(n);
	uart0_tx('.');
	n=(f-n)*1000000;
	uart0_tx_integer(n);
}
