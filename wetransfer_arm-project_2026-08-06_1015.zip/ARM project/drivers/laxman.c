#include <LPC21xx.H>
#include"header.h"

// --- Pin Definitions ---
#define RELAY_PIN       (1 << 6)   // P0.6 - Controls machine power
#define BUZZER_PIN      (1 << 7)   // P0.7 - Alarm buzzer
#define RED_LED_PIN     (1 << 17)   // P0.8 - Emergency/Alert Indicator
#define YELLOW_LED_PIN  (1 << 18)   // P0.9 - Warning Indicator
#define GREEN_LED_PIN   (1 << 19)   // P0.10 - Normal Status Indicator
//#define SW1 			(1 << 17)  //switch for gas
//#define SW2 			(1 << 18)  //switch for vibration



// Predefined Safety Thresholds
#define TEMP_THRESHOLD      45      // Celsius
#define CURRENT_THRESHOLD   500     // mA (via ACS712)
#define HUMIDITY_THRESHOLD  75      // Percentage

// Global Flags for non-ADC Digital Sensors
int fire_detected = 0;
int gas_detected = 0;
int vibration_detected = 0;

void gpio_init(void)
 {
    // Configure Alerts, Relay, and LCD Pins as Output
    IODIR0 |= (RELAY_PIN | BUZZER_PIN | RED_LED_PIN | YELLOW_LED_PIN | GREEN_LED_PIN);
    // Inputs: P0.10 (Gas Sensor), P0.11 (Vibration Sensor Setup)
    IODIR0 |=((1 << 16) | (1 << 17));
    // Turn off all alerts & activate default safe conditions
    IOCLR0 = (RED_LED_PIN | YELLOW_LED_PIN | BUZZER_PIN);
    IOSET0 = GREEN_LED_PIN | RELAY_PIN;
}



// ==========================================
// MAIN SYSTEM LOOP
// ==========================================
int main(void) {
    unsigned int temp_val=0, current_val=0, humidity_val=0;
    char string[50];
    char time[16];

   // Stage 1: System initialization
    gpio_init();
     lcd_init();
     adc_init();
     uart0_init(9600);
     i2c_init();
     spi0_init();
     can1_init();
     config_eint0();
    // config_eint1();
     lcd_cmd(0x80);
     lcd_string("INDUSTRIAL SAFETY");
     lcd_cmd(0xC0);
     lcd_string("SYSTEM init");
     delay_ms(5000);
     lcd_cmd(0x01); // Clear Display
     while (1) {
         // Stage 2: Sensor Monitoring (Read Analog Data)
         // Ch 0: LM35, Ch 1: ACS712, Ch 2: Humidity, P0.3: Gas Digital Input
         temp_val = (adc_read(1) * 330) / 1023;       // Convert to Approx Celsius
        // current_val = (adc_read(0) * 3300) / 1023;   // Convert to mA
        // humidity_val = (adc_read(2) * 100) / 1023;   // Percentage scaled
 
        // Read poll-based digital sensors
		
	    rtc_time(time);
  
        // Stage 13: Smart Decision-Making (AI-inspired branching logic)
		// CRITICAL PARAMETER: High Temperature
        if (temp_val > TEMP_THRESHOLD) {
            // Stage 4 Operations
            IOSET0 = RED_LED_PIN | BUZZER_PIN;
            IOCLR0 = GREEN_LED_PIN | YELLOW_LED_PIN | RELAY_PIN; // Disconnect machine
            lcd_cmd(0x80); lcd_string("HIGH TEMP ALERT ");
            sprintf(string, "TEMP: %d C ", temp_val);
            lcd_cmd(0xC0); lcd_string(string);
            uart0_tx_string("WARNING: HIGH TEMPERATURE DETECTED\r\n");
            sprintf(string, "\r\n[%s] HIGH TEMP: %dC", time, temp_val);
			uart0_tx_string(string);
			     lcd_cmd(0x01); // Clear Display

            //SPI_LogData(string);
            delay_ms(1000);
        }
        // CRITICAL EMERGENCY: Fire Detected
       else if (fire_detected) {
            // Stage 6 Operations
            IOSET0 = RED_LED_PIN | BUZZER_PIN;
            IOCLR0 = GREEN_LED_PIN | YELLOW_LED_PIN | RELAY_PIN; // Drop machine relay
            lcd_cmd(0x01);
            lcd_cmd(0x80); lcd_string("FIRE DETECTED!");
            uart0_tx_string("EMERGENCY: FIRE DETECTED\r\n");
            //CAN_Transmit(0x101, "FIRE_EMERGENCY");
            sprintf(string, "[%s] FIRE ERROR - SHUTDOWN", time);
			delay_ms(500);
			     lcd_cmd(0x01); // Clear Display
            //SPI_LogData(string);
            while(fire_detected) {
                // Keep system locked down safely until reset or external override
                IOSET0 = RED_LED_PIN; delay_ms(100);
                IOCLR0 = RED_LED_PIN; delay_ms(100);
            }
        }

        // EMERGENCY: Gas Leakage
        else if (gas_detected) {
            // Stage 5 Operations
            IOSET0 = BUZZER_PIN;
            IOCLR0 = GREEN_LED_PIN | RELAY_PIN; // Trip load
            lcd_cmd(0x80); lcd_string("GAS LEAKAGE DET ");

            // Blink Red LED
            IOSET0 = RED_LED_PIN; delay_ms(200);
            IOCLR0 = RED_LED_PIN; delay_ms(200);
            uart0_tx_string("EMERGENCY: GAS LEAKAGE DETECTED\r\n");
            //CAN_Transmit(0x102, "GAS_LEAK_DET");
            sprintf(string, "[%s] GAS LEAK DETECTED", time);
				delay_ms(500);
			     lcd_cmd(0x01); // Clear Display
            //SPI_LogData(string);
        }

        

        // CRITICAL PARAMETER: Over Current
        else if (current_val > CURRENT_THRESHOLD) {
            // Stage 8 Operations
            IOSET0 = RED_LED_PIN | BUZZER_PIN;
            IOCLR0 = GREEN_LED_PIN | RELAY_PIN;
            lcd_cmd(0x80); lcd_string("OVER CURRENT ALT");
            sprintf(string, "[%s] OVERCURRENT: %dmA", time, current_val);
			uart0_tx_string(string);
				delay_ms(500);
			     lcd_cmd(0x01); // Clear Display
            delay_ms(1000);
       }

        // WARNING: Machine Vibration
        else if (vibration_detected) {
            // Stage 7 Operations
            IOSET0 = YELLOW_LED_PIN | BUZZER_PIN;
            IOCLR0 = GREEN_LED_PIN; 
            // Relay remains ON during minor vibration warnings to avoid full disruption
            IOSET0 = RELAY_PIN; 
            lcd_cmd(0x80); lcd_string("VIBRATION ALERT ");
				delay_ms(500);
			     lcd_cmd(0x01); // Clear Display
            delay_ms(500);
        }

        // WARNING: High Humidity
        else if (humidity_val > HUMIDITY_THRESHOLD) {
            // Stage 9 Operations
            IOSET0 = YELLOW_LED_PIN;
            IOCLR0 = GREEN_LED_PIN;
            lcd_cmd(0x80); lcd_string("HIGH HUMIDITY  ");
				delay_ms(500);
			     lcd_cmd(0x01); // Clear Display
            delay_ms(500);
        }

        // Stage 3: Normal Condition Monitoring
        else {
            IOSET0 = GREEN_LED_PIN | RELAY_PIN; // Keep machine powered and safe
            IOCLR0 = RED_LED_PIN | YELLOW_LED_PIN | BUZZER_PIN;
            lcd_cmd(0x80); lcd_string("SYSTEM NORMAL");
            sprintf(string, "T:%dC H:%d%%       ", temp_val, humidity_val);
			uart0_tx_string(string);
            lcd_cmd(0xC0); lcd_string(string);
				delay_ms(500);
			     lcd_cmd(0x01); // Clear Display
            delay_ms(500);																					    
        }
    }
}

void rtc_time(char *time)
{
		unsigned int h,m,s;
		h=i2c_read(0xD1,0x2);
		m=i2c_read(0xD1,0x1);
		s=i2c_read(0xD1,0x0);
		if(h>>6&1)
		{
				if(h>>5&1)
					sprintf(time,"%x:%x:%x %s",h,m,s,"PM");
				else
					sprintf(time,"%x:%x:%x %s",h,m,s,"AM");
		}
		else
		sprintf(time,"%x:%x:%x",h,m,s);

}



