#include <LPC21xx.H>
#include"header.h"
void lcd_data(unsigned char data)
{	//higher nibble
	unsigned int t;
	IOCLR1=0xFE0000;
	t=(data&0xF0)<<16;
	IOSET1=t;
	IOSET1=1<<17;
	IOCLR1=1<<18;
	IOSET1=1<<19;
	delay_ms(2);
	IOCLR1=1<<19;

	//lower nibble
	IOCLR1=0xFE0000;
	t=(data&0x0F)<<20;
	IOSET1=t;
	IOSET1=1<<17;
	IOCLR1=1<<18;
	IOSET1=1<<19;
	delay_ms(2);
	IOCLR1=1<<19;
}
void lcd_cmd(unsigned char cmd)
{
	//higher nibble
	unsigned int t;
	IOCLR1=0xFE0000;
	t=(cmd&0xF0)<<16;
	IOSET1=t;
	IOCLR1=1<<17;
	IOCLR1=1<<18;
	IOSET1=1<<19;
	delay_ms(2);
	IOCLR1=1<<19;

	//lower nibble
	IOCLR1=0xFE0000;
	t=(cmd&0x0F)<<20;
	IOSET1=t;
	IOCLR1=1<<17;
	IOCLR1=1<<18;
	IOSET1=1<<19;
	delay_ms(2);
	IOCLR1=1<<19;
}
void lcd_init()
{
	IODIR1=0xFE0000;
//	PINSEL2  = 0x0;
	lcd_cmd(0x02);
	lcd_cmd(0x28);
	lcd_cmd(0x0e);
	lcd_cmd(0x01);
}
void lcd_string(char *p)
{
	while(*p!=0)
	{
		lcd_data(*p);
		p++;
	}
}

void lcd_integer(int n)
{
	char a[10];
	int i;
	if(n<0)
	{
		lcd_data('-');
		n=-n;
	}
	if(n==0)
	{
		lcd_data('0');
		return;
	}
	for(i=0;n;n/=10,i++)
		a[i]=n%10+48;
	for(i-=1;i>=0;i--)
		lcd_data(a[i]);
}

void lcd_float(float f)
{
	int n;
	if(f<0)
	{
		lcd_data('-');
		f=-f;
	}
	if(f==0)
	{
		lcd_string("0.0");
		return;
	}
	n=f;
	lcd_integer(n);
	lcd_data('.');
	n=(f-n)*1000000;
	lcd_integer(n);
}
