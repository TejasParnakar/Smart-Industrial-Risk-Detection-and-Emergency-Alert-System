
#include <LPC21xx.H>
#include<stdio.h>
//#include "header.h"
void rtc_time(char *time);
int main()
{
	char time[15];
	uart0_init(9600);
	rtc_time(time);
	uart0_tx_string("\r\n");
	uart0_tx_string(time);
}
void rtc_time(char *time)
{
		unsigned int h,m,s,k;
		h=0x10;//i2c_read(0xD1,0x2);
		m=0x23;//i2c_read(0xD1,0x1);
		s=0x53;//i2c_read(0xD1,0x0);
		k=1;
		if(k)
			sprintf(time,"%x:%x:%x %s",h,m,s,"AM");
		else
			sprintf(time,"%x:%x:%x %s",h,m,s,"PM");
	//	return time;
}
