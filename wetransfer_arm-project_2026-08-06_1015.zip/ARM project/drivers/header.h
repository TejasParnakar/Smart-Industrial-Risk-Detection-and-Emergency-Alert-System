typedef unsigned int u32;
typedef unsigned char u8;
typedef signed int s32;
typedef signed char s8;

#include<lpc21xx.h>
#include<stdio.h>
//delay
extern void delay_ms(unsigned int ms);
extern void delay_s(unsigned int s);

//LCD
extern void lcd_data(unsigned char data);
extern void lcd_cmd(unsigned char cmd);
extern void lcd_init(void);
extern void lcd_string (char *p);
extern void lcd_integer(int n);
extern void lcd_float(float f);

//UART
extern void uart0_rx_string(unsigned char *,int len);
extern void uart0_tx_string(char *);
extern unsigned char uart0_rx(void);
extern void uart0_tx(unsigned char data);
extern void uart0_init(unsigned int baud);
extern void uart0_tx_integer(int n);
extern void uart0_tx_float(float f);
extern void uart0_hex(s32 num);
extern void uart0_binary(int num);

//#define THRE (U0LSR>>5&1)
//#define RDR (U0LSR>>0&1)	`


//EINT's & UART intr's
extern void config_eint0(void);
extern void config_eint1(void);
extern void config_eint2(void);
extern void config_uart0_intr(void);

//MCP3204 & ADC(built in)
extern u32 mcp3204_adc_read(u8 ch_num);
extern u8 spi0(u8 data);
extern void spi0_init(void);
extern unsigned int adc_read(int ch);
extern void adc_init(void);

//I2C 
extern void i2c_init(void);
extern void i2c_send(u8 sa,u8 mr,u8 data);
extern u8 i2c_read(u8 sa, u8 mr);
extern void rtc_time(char *time);                                 

//CAN1
typedef struct CAN1_MSG{
	u32 id;
	u32 byteA;
	u32 byteB;
	u8 rtr;
	u8 dlc;
}CAN1;
extern void can1_init(void);
extern void can1_tx(CAN1 v);
extern void can1_rx(CAN1 *ptr);
extern void config_vic_for_can1(void);

extern void gpio_init(void);



#define DHT11_PIN 18 //P0.18 for the DHT11 Data Line
extern void delay_us(unsigned int us);
extern unsigned char DHT11_ReadByte(void);
extern unsigned char Read_DHT11(unsigned char *humidity, unsigned char *temperature) ;

extern void dht11_start(void);
extern unsigned char DHT11_ReadByte(void);