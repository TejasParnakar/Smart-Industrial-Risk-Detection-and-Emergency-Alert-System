#include <LPC21xx.H>
#include "header.h"

void adc_init()
{
   PINSEL1 |= 0x15400000; // P0.27=Ain0 P0.28=Ain1, P0.29=Ain2, P0.30=Ain3
    ADCR = 0x00200400; // Select CH1,CH2,CH3, 10-bit, CLKDIV=4
}

// Read ADC channel 0-7
unsigned int adc_read(int ch)
{
    ADCR|=1<<ch;
	ADCR|=1<<24;
	while((ADDR>>31&1)==0);
	ADCR^=1<<24;
	ADCR^=1<<ch;
	return ((ADDR>>6)&0x3ff);
}

