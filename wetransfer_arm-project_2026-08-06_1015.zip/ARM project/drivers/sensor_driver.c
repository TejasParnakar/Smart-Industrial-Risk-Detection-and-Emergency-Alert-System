//sensor_driver.c
//#include<lpc21xx.h>

#include"header.h"

//dht11 Driver.....

unsigned char DHT11_ReadByte(void) 
{
	unsigned char result = 0;
	int i;
	for (i = 0; i < 8; i++) 
	{ 
		while (!(IOPIN0 & (1 << DHT11_PIN))); 

		delay_us(40);  
		if (IOPIN0 & (1 << DHT11_PIN)) 
		{  
			result |= (1 << (7 - i));  
			while (IOPIN0 & (1 << DHT11_PIN)); 
		}
	}return result;
}

unsigned char Read_DHT11(unsigned char *humidity, unsigned char *temperature) 
{unsigned char data[5];
	PINSEL0 &= ~(3 << 4); // Configure P0.18
	IODIR0 |= (1 << DHT11_PIN); 
	IOCLR0 = (1 << DHT11_PIN); 
	delay_ms(20); 
	IOSET0 = (1 << DHT11_PIN); 
	delay_us(30); 
	IODIR0 &= ~(1 << DHT11_PIN); 
	if (!(IOPIN0 & (1 << DHT11_PIN))) { 
		while (!(IOPIN0 & (1 << DHT11_PIN))); 
		while (IOPIN0 & (1 << DHT11_PIN));   
		data[0] = DHT11_ReadByte();  
		data[1] = DHT11_ReadByte(); 
		data[2] = DHT11_ReadByte();  
		data[3] = DHT11_ReadByte(); 
		data[4] = DHT11_ReadByte();  

		if (data[4] == (data[0] + data[1] + data[2] + data[3])) 
		{ *humidity = data[0]; *temperature = data[2]; 
			return 1;  
		}}return 0; 
}

