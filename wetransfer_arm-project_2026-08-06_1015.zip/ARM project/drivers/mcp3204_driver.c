/*mcp3204_driver.c*/

#include <LPC21xx.H>
#include "header.h"
 
u32 mcp3204_adc_read(u8 ch_num)
{
	u8 byteH,byteL;
	u32 result=0;
	ch_num<<=6;//set ch_num
	
	IOCLR0=(1<<7);//CS0=0
	spi0(0x06);
	byteH=spi0(ch_num);
	byteL=spi0(0x00);
	IOSET0=(1<<7);//CS0=1
	
	byteH&=0x0F;
	result=(byteH<<8)|byteL;
	return result;
}
