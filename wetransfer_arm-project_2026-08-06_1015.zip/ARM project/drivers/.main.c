#include <lpc21xx.h>
//#include <stdio.h>

#define THRESHOLD_TEMP 60 // 60�C
#define THRESHOLD_GAS 500 // ADC value
#define THRESHOLD_VIB 400 // ADC value

// LCD Pins - assuming 4-bit mode on P0.0 to P0.7
#define RS (1<<8)
#define EN (1<<9)
#define LCD_DATA (0xFF<<0)

void delay_ms(unsigned int ms) {
    unsigned int i,j;
    for(i=0;i<ms;i++)
        for(j=0;j<6000;j++);
}

// LCD Functions
void LCD_cmd(unsigned char cmd) {
    IO0CLR = LCD_DATA | RS;
    IO0SET = (cmd<<0);
    IO0SET = EN;
    delay_ms(2);
    IO0CLR = EN;
    IO0CLR = LCD_DATA;
    IO0SET = (cmd<<4);
    IO0SET = EN;
    delay_ms(2);
    IO0CLR = EN;
}

void LCD_data(unsigned char data) {
    IO0SET = RS;
    IO0SET = (data<<0);
    IO0SET = EN;
    delay_ms(2);
    IO0CLR = EN;
    IO0CLR = LCD_DATA;
    IO0SET = (data<<4);
    IO0SET = EN;
    delay_ms(2);
    IO0CLR = EN;
}

void LCD_init() {
    IO0DIR |= LCD_DATA | RS | EN;
    delay_ms(20);
    LCD_cmd(0x02); // 4-bit
    LCD_cmd(0x28); // 2 line
    LCD_cmd(0x0C); // Display on
    LCD_cmd(0x06); // Entry mode
    LCD_cmd(0x01); // Clear
}

void LCD_string(char *str) {
    while(*str) LCD_data(*str++);
}

// ADC Init for LPC2129 - Channel 0,1,2
void ADC_init() {
    PINSEL1 |= (1<<14)|(1<<16)|(1<<18); // P0.28=AD0.1, P0.29=AD0.2, P0.30=AD0.3
    AD0CR = (1<<1)|(1<<2)|(1<<3)|(1<<21)|(4<<8); // Select CH1,CH2,CH3, 10-bit, CLKDIV=4
}

// Read ADC channel 0-7
unsigned int ADC_read(int ch) {
    AD0CR &= 0xFFFFFF00;
    AD0CR |= (1<<ch) | (1<<24) | (1<<21); // Start conversion
    while((AD0DR[ch] & (1<<31)) == 0); // Wait for DONE
    return (AD0DR[ch] >> 6) & 0x3FF; // 10-bit result
}

// Output Pins
#define RED_LED (1<<10)
#define GREEN_LED (1<<11)
#define BUZZER (1<<12)
#define RELAY (1<<13)

void alert_system(int risk) {
    if(risk) {
        IO0SET = RED_LED | BUZZER | RELAY; // Alert ON, Machine OFF
        IO0CLR = GREEN_LED;
        LCD_cmd(0xC0);
        LCD_string("RISK DETECTED!");
    } else {
        IO0SET = GREEN_LED;
        IO0CLR = RED_LED | BUZZER | RELAY;
        LCD_cmd(0xC0);
        LCD_string("SYSTEM NORMAL ");
    }
}

int main() {
    unsigned int temp_val, gas_val, vib_val;
    float temperature;
    int risk = 0;
    
    IO0DIR |= RED_LED | GREEN_LED | BUZZER | RELAY;
    
    LCD_init();
    ADC_init();
    
    LCD_cmd(0x80);
    LCD_string("Smart Risk Sys");
    delay_ms(1000);
    
    while(1) {
        risk = 0;
        
        // Read Sensors
        temp_val = ADC_read(1); // LM35 on AD0.1
        gas_val = ADC_read(2); // MQ2 on AD0.2
        vib_val = ADC_read(3); // Vibration on AD0.3
        
        // Convert LM35: 10mV per �C, Vref=3.3V, 10-bit ADC
        temperature = (temp_val * 3.3 * 100) / 1023; 
        
        // Display on LCD
        LCD_cmd(0x80);
        printf_lcd: // pseudo - you can format and send
        LCD_string("T:"); 
        // Add number printing function here
        
        // Check thresholds
        if(temperature > THRESHOLD_TEMP || gas_val > THRESHOLD_GAS || vib_val > THRESHOLD_VIB) {
            risk = 1;
        }
        
        alert_system(risk);
        delay_ms(500);
    }
}