#include <LPC21xx.H>
#include"header.h"
