main.o: drivers\main.c
main.o: C:\Keil4\ARM\INC\Philips\LPC21xx.H
main.o: drivers\header.h
main.o: C:\Keil4\ARM\RV31\INC\stdio.h
