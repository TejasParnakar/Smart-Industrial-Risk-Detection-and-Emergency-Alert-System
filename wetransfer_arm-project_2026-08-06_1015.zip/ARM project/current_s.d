current_s.o: C:\Documents and Settings\VECTOR\Desktop\vibration sensor\current_s.c
current_s.o: C:\Keil4\ARM\INC\Philips\LPC21xx.h
current_s.o: C:\Documents and Settings\VECTOR\Desktop\vibration sensor\header.h
