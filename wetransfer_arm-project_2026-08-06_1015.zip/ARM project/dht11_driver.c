#include "header.h"
#include <lpc21xx.h>
void dht11_start(void)
{
	 IODIR0|=DHT11_PIN;
	 IOCLR0=DHT11_PIN;
	 delay_ms(18);//data low for 18ms -start signal
	 IOSET0=DHT11_PIN;
	 delay_us(30);
  IODIR0 &= ~(DHT11_PIN);//make p0.7 as input pin, after this dht11 will be ready, giving ack by low the line for 80us and high for 80us
 // delay_us(80);
	 while(IOPIN0 & DHT11_PIN);//waiting for low the line, means data starts send after this
  while(!(IOPIN0 & DHT11_PIN));    // Wait for HIGH
  while(IOPIN0 & DHT11_PIN);       // Wait for LOW (start of data)
  return;
}

unsigned char DHT11_ReadByte(void)
{
    unsigned char i,data=0;

    for(i=0;i<8;i++)
    {
        while(!(IOPIN0 & DHT11_PIN));

        delay_us(40);

        if(IOPIN0 & DHT11_PIN)
            data |= (1<<(7-i));

        while(IOPIN0 & DHT11_PIN);
    }

    return data;
}